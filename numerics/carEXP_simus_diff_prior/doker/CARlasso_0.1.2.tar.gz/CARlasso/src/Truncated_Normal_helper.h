# ifndef TRUNCATED_NORMAL_HELPER_H
# define TRUNCATED_NORMAL_HELPER_H
 
double rtn1(const double mean,
	    const double sd,
	    const double low,
	    const double high
	    ) ;

# endif
