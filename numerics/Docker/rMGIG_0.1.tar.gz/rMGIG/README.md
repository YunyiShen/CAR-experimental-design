![](https://github.com/YunyiShen/rMGIG/workflows/R-CMD-check/badge.svg)

# rMGIG
Sample from Matrix Generalized Inverse Gaussian (MGIG) Distribution using Importance Sampling in R following

Fazayeli, Farideh, and Arindam Banerjee. "The matrix generalized inverse Gaussian distribution: Properties and applications." *Joint European Conference on Machine Learning and Knowledge Discovery in Databases.* Springer, Cham, 2016.
